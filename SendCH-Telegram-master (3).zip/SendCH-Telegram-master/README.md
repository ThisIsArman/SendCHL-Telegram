## SendCH Telegram
**Send message for channel (Telegram) using the Markdown or HTML.**

## Requires for Run
- Apache2

- Php5

- Php5-curl


## Pages
Project [WebSite](http://sendch-tiagoedge.rhcloud.com/)

Suggestions and Support [New Issue](https://github.com/TiagoDanin/SendCH-Telegram/issues/new)

## Collaborator
GualterPerinho

## LICENSE
Creative Commons Attribution 3.0 [(CCA)](https://github.com/TiagoDanin/SendCH-Telegram/blob/master/LICENSE)

---
>Copyright (c) 2016 Tiago Danin
